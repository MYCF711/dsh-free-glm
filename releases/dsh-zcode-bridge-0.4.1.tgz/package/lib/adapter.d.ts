/**
 * ZCode 桥适配器。
 *
 * ## 与其它 provider 的根本差别
 *
 * 上游**不是**标准 OpenAI SSE 服务，而是一个**非流式的本地桥**：
 *
 *   请求  POST http://127.0.0.1:<port>/v1/chat/completions
 *   响应  {"choices":[{"message":{"content":"..."},"finish_reason":"stop"}], "usage":{...}}
 *
 * 实测确认（`bridge-e2e` / `probe`）：
 *   - 传 `stream: true` 被**忽略** —— 始终返回 application/json 整包
 *   - `usage` 恒为 `{prompt_tokens:0, completion_tokens:0, total_tokens:0}`
 *     （桥内部拿不到真实用量），所以**不上报 usage**，而不是报一堆 0
 *
 * 因此本适配器**不消费 SSE** —— 按 SSE 帧解析的读法喂给它一个 JSON 整包
 * 会一行都读不出来（表现为模型不说话）。桥返回什么就整包 JSON 解析。
 *
 * ⚠ 本插件**没有** SSE 消费代码。早先版本从其它 provider 适配器抄来了一份
 *   `sse.ts` + `openai-compat.ts`（约 700 行），对本桥完全无用，已删除 ——
 *   留着会误导后来者以为"某个路径会走 SSE"。
 *
 * ## 做法
 *
 * 拿到整包后，把文本**切成片段**逐个 yield，合成 DSH 期望的流式形状。
 * 这样：
 *   1. 满足 `StreamChunk` 的顺序契约（block-start → delta* → block-end → finish）
 *   2. 用户在界面上能看到渐进输出，而不是干等十几秒后一次性出现
 *
 * 分片只是**呈现层**的模拟 —— 上游确实是一次性返回的。切分粒度取
 * 一个视觉上自然的折中值。
 *
 * ## 工具调用：提示词化桥接
 *
 * 桥**没有 `tools` 通道**（`sendPrompt` 只收 `content: string`，只有
 * `toolDenylist` 无 allowlist），所以无法把 DSH 的 `tools[]` 透传给上游。
 *
 * 做法（见 `tool-bridge.ts`）：
 *   1. 把 `tools[]` 渲染成提示词，追加到 system 段
 *   2. 与模型约定输出 ```json 围栏包裹的 `{"tool":...,"arguments":{...}}`
 *   3. 在 `stream()` 里解析回复，命中则**合成** `tool-call` 块序列
 *   4. 有工具调用时 `finish` 用 `{ kind: 'tool-calls' }`
 *
 * 实测（GLM-5.3-Flash，19 秒）模型一次命中且格式完全正确。
 * 契约只约束 chunk 序列，不关心工具调用是谁产生的，所以这条路径合法。
 */
import { LlmAdapter } from "@deepseek-ai/dsh-llm";
import type { GenerateOptions, LlmModelInfo, LlmProviderInfo, LlmResolvedModelInfo, StreamChunk } from "@deepseek-ai/dsh-llm";
import { type ZCodeBridgeProduct } from "./product.js";
import type { ModelVisibility } from "./model-visibility.js";
/** 适配器构造参数。 */
export interface ZCodeBridgeAdapterOptions {
    /** 产品描述对象；省略用 {@link ZCODE_BRIDGE}。 */
    readonly product?: ZCodeBridgeProduct;
    /** 日志（DSH 的 ctx.logger 兼容签名）。 */
    readonly logger?: {
        info: (...args: unknown[]) => void;
        warn: (...args: unknown[]) => void;
    };
    /** 单次请求的总超时（毫秒）。桥侧默认 180s，这里留余量。 */
    readonly requestTimeoutMs?: number;
    /** 文本分片大小（字符）。仅影响呈现粒度。 */
    readonly chunkChars?: number;
    /**
     * 模型可见性（拨动开关）。
     *
     * 注入后 `listModels()` 会按黑名单过滤；设置页通过 `listAllModels()`
     * 拿全量目录来渲染开关。省略则不过滤（headless/CLI profile 无需开关）。
     */
    readonly visibility?: ModelVisibility;
    /**
     * 【按需拉起】确保壳可用；不可用就自己拉起来并等就绪。
     *
     * 由 `index.ts` 注入（那里才有 `spawnConfig` 与保活上下文）。
     * 返回 `true` = 桥可用。
     *
     * ## 为什么放在适配器里而不是只在插件启动时做
     *
     * 早先只有「DSH 启动时拉起」+「后台保活」。壳挂掉后用户一发消息就直接吃
     * `MISSING_CREDENTIAL`，得自己想办法重启 —— 那是把「壳没跑」当成用户的错误。
     *
     * `prepareCall()` 是**每轮请求开始**的挂载点，在这兜底最合适：
     * 用户点发送 → 插件先确保依赖在 → 再真正发请求。
     */
    readonly ensureReady?: () => Promise<boolean>;
}
export declare class ZCodeBridgeAdapter extends LlmAdapter {
    private readonly product;
    private readonly logger;
    private readonly requestTimeoutMs;
    private readonly chunkChars;
    /** 最近一次成功解析的端点 —— 仅供诊断输出，不作为请求路径的缓存依据。 */
    private lastResolvedSource;
    /** 桥播报的模型集（`undefined` = 采信静态全表）。 */
    private advertisedModelIds;
    /** 模型可见性（拨动开关）。未注入时不过滤。 */
    private visibility;
    /**
     * 【流式】收到**第一个**文本增量时的回调。
     *
     * 用途：让 `stream()` 不必干等整轮结束就能开始输出。
     *
     * 为什么是「首个」而不是「每个增量」：工具调用的解析需要完整文本
     * （见 `consumeSse` 的说明），所以只借首字节做一件事 —— **尽快开一个
     * 文本块**，消除「卡在思考、不吐文本」的空白期。
     */
    private onFirstText;
    /** 【按需拉起】插件注入的「确保壳可用」回调。 */
    private ensureReady;
    /** 上次「确保」的结果与时间 —— 避免每轮都白等一次探测。 */
    private lastEnsureAt;
    private lastEnsureOk;
    constructor(options?: ZCodeBridgeAdapterOptions);
    /** 生命周期钩子：注册后调用，可空。 */
    start(): void;
    /** 生命周期钩子：dispose 时调用，可空。 */
    dispose(): void;
    /** 当前端点的来源（`env` / `discovery-file` / `unavailable`），供诊断。 */
    endpointSource(): string;
    /**
     * 消费桥的 SSE 流，合成为一次完整响应。
     *
     * ## 为什么"合成完整响应"而不是边收边 yield
     *
     * 工具调用的解析必须拿到**完整文本**才能做（JSON 围栏可能跨多个 delta）。
     * 边流边解析会引入"半个围栏"的中间态，极易误判 —— 而误判的代价是
     * DSH 去执行一个模型根本没要求的工具。
     *
     * 所以这里只做两件事：
     *   1. **尽快感知到"已经有内容了"** —— 通过 `onFirstText` 回调让上层
     *      立刻发一个文本块开始（消除"卡在思考"的空白期）
     *   2. 合成完整 payload，交给原有解析逻辑
     *
     * ## 与"真正流式"的差别
     *
     * 用户看到的是**先出现一个文本块、随后一次性补全**，而不是逐字冒出。
     * 这是刻意取舍：正确性优先于观感。若将来要逐字流，需要让桥把
     * "工具协议围栏"与"普通文本"分开推 —— 那是另一层改造。
     */
    private consumeSse;
    /**
     * provider 信息。
     *
     * ⚠ `id` 必须等于注册时用的路由名，否则 DSH 校验失败。
     */
    providerInfo(provider: string): LlmProviderInfo;
    /**
     * 模型目录（**已按开关过滤**）。
     *
     * **桥不可用时返回 `[]`，绝不抛错** —— 抛错会在界面上变成一条 provider
     * 失败记录；返回空数组会让 DSH 把整个分组过滤掉，视觉上就是"没这个
     * provider"，这才是"ZCode 没启动"应有的表现。
     *
     * ⚠ **每次都实时读黑名单，绝不能缓存过滤结果** —— 这是「拨动开关即时生效」
     *   的全部机制。对话框的模型选择器每次打开都会调本方法，读到的是最新副本。
     */
    listModels(_provider: string): Promise<readonly LlmModelInfo[]>;
    /**
     * 全量模型目录（**不受开关影响**）。
     *
     * 为什么要单独提供：`listModels()` 返回的目录已被黑名单过滤，
     * 若设置页拿它来渲染开关，被关闭的模型会**连开关一起消失**，
     * 用户再也无法重新打开它。
     *
     * `ctx.llm` 不透传自定义方法（只保证 `listModels`），所以设置页必须
     * 自己持有适配器实例来调本方法 —— 见 `getRegisteredZCodeBridgeAdapter()`。
     *
     * 同步方法（无 IO）：目录来自静态表 + 桥的探活结果缓存，UI 需要立刻拿到。
     */
    listAllModels(): readonly LlmModelInfo[];
    /**
     * 刷新桥播报的模型集，并返回桥是否可用。
     *
     * 由 `listModels()` / 设置页调用；结果缓存在 `advertisedModelIds`，
     * 让同步的 `listAllModels()` 也能拿到。
     */
    refreshCatalog(): Promise<boolean>;
    /** 解析单个模型的能力与窗口。 */
    resolveModel(provider: string, model: string, _signal?: AbortSignal): Promise<LlmResolvedModelInfo>;
    /**
     * 兼容 shim。
     *
     * 新版 `LlmRuntime.prepareCall()` 会调用 `registration.adapter.prepareCall(...)`；
     * 基类缺该方法时每轮请求开始会抛 `prepareCall is not a function`。
     * Jet Hub 的 zcode / qoder / buddy 三处都是同款写法。
     *
     * ## 【按需拉起】这里是确保壳可用的挂载点
     *
     * `prepareCall` 是**每轮请求开始**都会走的路径，所以在这兜底最自然：
     * 用户点发送 → 先确保依赖在 → 再真正发请求。
     *
     * 注入了 `ensureReady` 时才做，且**失败不抛错** —— 让后续 `stream()`
     * 自己去报那条更明确的 `MISSING_CREDENTIAL`（它知道怎么描述缺什么）。
     */
    prepareCall(provider: string, model: string, signal?: AbortSignal): Promise<{
        model: LlmResolvedModelInfo;
        stream: (options: GenerateOptions) => AsyncIterable<StreamChunk>;
    }>;
    /** 上次「按需拉起」的结果（供设置页/诊断显示）。 */
    ensureStatus(): {
        ok: boolean;
        at: number;
    };
    /**
     * 执行一次对话。
     *
     * 顺序契约（DSH 强制）：block-start → text-delta* → block-end → finish。
     * finish 之后不得再 yield。
     */
    stream(options: GenerateOptions): AsyncIterable<StreamChunk>;
}
//# sourceMappingURL=adapter.d.ts.map