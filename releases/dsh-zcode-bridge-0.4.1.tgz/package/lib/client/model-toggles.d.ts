/**
 * 模型设置页组件 —— 挂在**原生模型设置区**的 provider 卡片里。
 *
 * ## 用户要求
 *
 * 「把模型显示页面直接插入到设置的模型中作为模型供应商显示，
 *   展开后直接显示模型名称，右边增加原点拨动开关，实时生效」
 *
 * ## 挂载点
 *
 * `settings.models.provider-card` 是 DSH 官方模型设置页声明给外部插件的
 * 扩展槽（`dsh-client-ui-settings-models` 的 slot-contract）。
 *
 * 它在**三处** dispatch（实测 `lib/client.js` offset 104602 / 107712 / 112009）：
 *   1. 首次配置的 setup card
 *   2. 已保存的行
 *   3. 新增 provider 的草稿卡
 *
 * 三处都用同一个 props 形状：
 *   ```js
 *   renderSlot("settings.models.provider-card",
 *     { provider: row.entry, configured: row.configured, keyConfigured: keyConfiguredOf(row) },
 *     { entryKey: row.entry.settingsNs })
 *   ```
 * **`entryKey` 是我们的 settingsNs** —— 只在自己的卡片里渲染，不干扰别人。
 *
 * ## 为什么不用 React
 *
 * 宿主页面是 React，但这个扩展槽只要求「一个渲染函数」。用原生 DOM
 * 可以完全避开对 React 版本/JSX 构建的耦合 —— 插件的 `lib/` 是纯 tsc
 * 产物，没有 JSX 编译步骤。
 *
 * ## 「实时生效」的实现
 *
 * 开关写入 → 宿主 `settings` 落盘 + 适配器进程内副本更新。
 * 模型选择器下次打开时调 `listModels()`，读到的是**过滤后的新目录**。
 * 不需要任何事件广播 —— 见 `adapter.ts` 的 `listModels()`。
 *
 * 本组件只负责把「全量目录 + 开关状态」渲染出来。全量目录必须走
 * `listAllModels()`（不过滤），否则被关闭的模型会连开关一起消失，
 * 用户再也无法重新打开。
 */
/** 组件收到的 owner props（由宿主 dispatch 注入）。 */
export interface ProviderCardOwnerProps {
    /** 该卡片的目录行。 */
    readonly provider: {
        readonly provider: string;
        readonly displayName: string;
        readonly settingsNs: string;
        readonly settingsPath: readonly string[];
        readonly active: boolean;
        readonly declared?: boolean;
        readonly error?: string;
    };
    /** 是否有任一配置层配置了该 provider。 */
    readonly configured: boolean;
    /** 引用的 api-key 凭据是否已配置。 */
    readonly keyConfigured: boolean;
}
/** 客户端上下文里我们用到的最小面。 */
export interface ClientCtx {
    readonly logger?: {
        info?: (m: unknown) => void;
        warn?: (m: unknown) => void;
    };
    readonly get?: (name: string) => unknown;
}
/** 宿主注入的依赖（由 apply 时的闭包提供）。 */
export interface ModelToggleDeps {
    /** 本 provider 的路由名。 */
    readonly providerId: string;
    /** 本插件的 settings namespace（用于判断是否该渲染）。 */
    readonly settingsNs: string;
    /** 全量模型目录（不过滤）。 */
    listAllModels: () => readonly {
        id: string;
        name: string;
    }[];
    /** 某 model 当前是否被关闭。 */
    isDisabled: (modelId: string) => boolean;
    /** 打开/关闭某 model。 */
    setDisabled: (modelId: string, disabled: boolean) => Promise<void>;
}
/**
 * 渲染 provider 卡片里的模型开关区。
 *
 * 返回一个 DOM 元素；宿主把它插进卡片。
 */
export declare function renderModelToggles(props: ProviderCardOwnerProps, deps: ModelToggleDeps, ctx: ClientCtx): HTMLElement | null;
//# sourceMappingURL=model-toggles.d.ts.map