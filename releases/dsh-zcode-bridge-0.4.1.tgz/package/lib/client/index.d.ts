/**
 * DSH 客户端插件入口 —— 把模型开关挂进原生模型设置页。
 *
 * ## 怎么被加载
 *
 * `package.json` 里声明 `dsh.client = { platform: "web" }`，
 * 并导出 `./client`。DSH 的 web 前端会把它作为浏览器侧插件加载。
 *
 * ## 与主插件的关系
 *
 * 主插件（`lib/index.js`）跑在 Host，负责 provider 注册与适配器；
 * 本模块跑在浏览器，只负责设置页的 UI。两者通过 **settings** 通信：
 *   - UI 读：`SettingsDescribeMirror` 的 `namespace("zcode-bridge")`
 *   - UI 写：`settings.mutate`（路径操作，不重述整个 section）
 *   - 主插件：适配器 `listModels()` 实时读同一份 section 的 `disabledModels`
 *
 * **不需要自建 RPC** —— DSH 的 settings wire 已经覆盖读写两向。
 */
import type { Context } from "@deepseek-ai/cordis";
/**
 * `ctx.slots` 是 `@deepseek-ai/dsh-client-ui-slots` 通过模块增强加到
 * `@deepseek-ai/cordis` 的 `Context` 上的。本插件不依赖那个包（它由 DSH
 * 前端提供），所以在这里就地声明用到的那两个方法。
 *
 * 只声明 `inject` 与 `register` —— 它们已由 codearts-auth 的客户端插件
 * 实测跑通（`lib/client/jet-hub.js:1546`）。
 */
declare module "@deepseek-ai/cordis" {
    interface Context {
        readonly slots: {
            inject<T>(name: string, factory: () => T): void;
            register<T>(def: Record<string, unknown>, component: (props: never) => T): unknown;
        };
    }
}
/** 客户端插件名。 */
export declare const name = "zcode-bridge-client";
/**
 * 静态注入。
 *
 * `slots` 是挂 UI 必需的（`ctx.slots.inject` / `ctx.slots.register`）。
 * `settings` 走 `ctx.get()` 可选取用 —— 静态注入会让插件在缺该服务的
 * 环境里永久 pending，进而整个 profile 加载失败。
 */
export declare const inject: string[];
/** 客户端插件入口。 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map