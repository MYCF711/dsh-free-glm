/**
 * ZCode 桥的宿主侧 RPC —— 让设置页的客户端 UI 能操作账号。
 *
 * ## 为什么需要它
 *
 * 客户端插件跑在**浏览器**里，而三个账号操作（添加账号 / 签到 / 持续领取）
 * 只能由 **Host 侧**执行 —— 它们要读本机发现文件、调实例的 HTTP 桥。
 * 浏览器拿不到文件系统，必须有一条通道把请求转过来。
 *
 * ## 通道形态（照抄 dsh-codearts-auth 的既有模式）
 *
 * `dsh-codearts-auth` 用 DSH 的 `connection.fetch.register()` 注册一条
 * HTTP 端点，通道名 → 路径 `/api/<name>`。客户端用
 * `connection.rpc.call("/api", <channel>, { method, payload })` 调用。
 *
 * 本模块复用同一模式（**不自己发明协议**）：
 *
 * ```
 * Host   : connection.fetch.register({ path: <API_PATH>, methods:["POST"], ... })
 * Client : connection.rpc.call("/api", RPC_CHANNEL, { method, payload })
 * ```
 *
 * ## 端点方法
 *
 * | method | 作用 | 底层 |
 * |---|---|---|
 * | `status`        | 账号状态（额度 / 到期 / 权益模型） | `fetchBilling()` |
 * | `addAccount`    | 添加账号（拉起实例的 OAuth） | `requestCliLogin()` |
 * | `checkin`       | 每日签到（领取额度） | `requestClaim()` |
 * | `startAutoClaim`| 持续领取（定时自动领取） | `createQuotaGuard()` |
 *
 * ## 与「持续领取」的关系
 *
 * `quota-guard` 默认**已在主插件启动时运行**（见 `index.ts`）。本 RPC 的
 * `startAutoClaim` 是给用户一个**显式确认/重启**的入口 —— 若它已经在跑，
 * 返回"已在运行"而不是起第二个（两个 guard 会重复领取，服务端虽幂等，
 * 但会白白消耗 captcha 配额）。
 */
import type { Context } from "@deepseek-ai/cordis";
/** RPC 通道名 —— 客户端必须用同一个值。 */
export declare const RPC_CHANNEL = "zcode-bridge";
/** 端点路径（DSH 会把它挂在 `/api/zcode-bridge`）。 */
export declare const RPC_PATH = "/api/zcode-bridge";
/**
 * 注册 RPC 端点。
 *
 * ⚠ **失败只 warn 不抛** —— 端点注册不上时，设置页的三个按钮会显示
 * "Host 侧未提供该接口"，而不是让整个插件加载失败。
 */
export declare function registerZcodeBridgeRpc(ctx: Context): void;
/**
 * 持续领取的运行状态 —— 由主插件在启动 quota-guard 时置位。
 *
 * 用模块级可变对象而不是「去问 guard」：guard 的 `stop` 存在但
 * 没有「是否运行中」的查询面，加一个查询面要改 guard 的接口；
 * 而这里只需要一个布尔，用共享状态最省。
 */
export declare const autoClaimState: {
    running: boolean;
};
//# sourceMappingURL=bridge-rpc.d.ts.map