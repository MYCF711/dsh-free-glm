/**
 * 每日额度守卫（2026-09-28 新增）。
 *
 * ## 它解决什么
 *
 * 用户的两条诉求：
 *
 * 1. 「登录授权成功后，插件就能直接让 DSH 调用 zcode 的每日免费订阅额度」
 * 2. 「还要时刻检索每日随机派发的大额额度，自动领取」
 *
 * ## 为什么需要「检索」
 *
 * 服务端**不会主动推送**额度。ZCode 客户端左下角那张卡片，其数据源是
 * `GET /billing/preview` —— 而该接口的内容**依赖客户端的活跃信号**：
 *
 * 实测（本项目，跨版本一致）：
 * ```
 * 补发 POST /api/v1/event/report {app_launch, app_daily_active} 之前：
 *   preview → {"code":0,"data":{"plans":[]}}            ← 空
 * 补发之后：
 *   preview → {"code":0,"data":{"plans":[{plan_id:"zcode-v3-start-plan-trust-0928"...}]}}
 * ```
 *
 * **⇒ 「随机派发」不是随机推送，而是「服务端按活跃信号决定要不要给」。**
 * 所以「时刻检索」的正确实现是：**定期补发活跃信号 + 查 preview + 有就领**。
 *
 * ## 安全边界（实测）
 *
 * - **幂等**：已领取时服务端返回 `code:1003`，连调 3 次结果一致、
 *   且**不消耗额度**（实测剩余量未变）
 * - **有轮询风险**：第三方实现提到 `billing/*` 连续查询易触发 WAF，
 *   所以默认间隔取 **20 分钟**（一天 72 次，远低于风险阈值）
 * - **失败不抛**：单个周期失败只记日志，不影响下一个周期
 */
import { type BillingData, type ClaimData } from "./bridge-ops.js";
export interface QuotaGuardOptions {
    readonly log: {
        info: (message: string) => void;
        warn: (message: string) => void;
    };
    /** 检索间隔（毫秒）。未设置时用 `ZCODE_QUOTA_GUARD_INTERVAL_MS` 或默认值。 */
    readonly intervalMs?: number;
    /** 失败冷却（毫秒）。未设置时用 `ZCODE_QUOTA_GUARD_COOLDOWN_MS` 或默认值。 */
    readonly cooldownMs?: number;
    /** 首次延迟（毫秒）。 */
    readonly firstDelayMs?: number;
}
export interface QuotaGuard {
    /** 立刻跑一次（用户手动触发 / 登录后补跑）。 */
    runOnce: () => Promise<QuotaGuardTick>;
    /** 停止定时器。 */
    stop: () => void;
}
/** 一个检索周期的结果（供上层展示或日志）。 */
export interface QuotaGuardTick {
    readonly at: number;
    /** 额度快照（拿不到时为 undefined）。 */
    readonly billing?: BillingData;
    /** 本周期是否调了 claim。 */
    readonly claimed: boolean;
    /** claim 结果（调了才有）。 */
    readonly claim?: ClaimData;
    /** 人类可读的一句话结论。 */
    readonly summary: string;
}
/**
 * 创建守卫。
 *
 * ## 为什么用 `setTimeout` 递归而不是 `setInterval`
 *
 * 一轮检索实测 2-30 秒（含 mint + claim）。`setInterval` 会在上一轮
 * 还没结束时叠下一轮，导致并发 mint（captcha 会互相抢）。
 * 递归 `setTimeout` 保证**串行**。
 */
export declare function createQuotaGuard(options: QuotaGuardOptions): QuotaGuard;
//# sourceMappingURL=quota-guard.d.ts.map