/**
 * 桥发现 —— 解析出可用的 `{ baseUrl, token }`。
 *
 * 两级来源（与 Jet Hub 其它 provider 的 `resolveBaseUrl` 同风格）：
 *   1. 环境变量 `ZCODE_BRIDGE_BASE_URL` + `ZCODE_BRIDGE_TOKEN`（显式覆盖）
 *   2. 发现文件 `<dataBaseDir>/.zcode/v2/bridge-port.json`（读端口 + token）
 *
 * ⚠ 这里**不缓存**。桥每次启动端口都会变（`port: 0` 随机分配），
 * 而插件在 DSH 进程里常驻 —— 缓存会让 ZCode 重启后插件一直打旧端口。
 * 发现文件读取是极廉价的操作（一个几 KB 的 JSON），每次请求读一次可接受；
 * 真正的开销在桥那边的模型调用（数秒级）。
 */
import { type ZCodeBridgeEndpoint, type ZCodeBridgePortFile } from "./product.js";
/**
 * 解析 ZCode 数据根目录。
 *
 * 解析顺序：
 *   1. 显式 `ZCODE_DATA_BASE_DIR` 环境变量
 *   2. 已知候选目录中**发现文件真的存在**的那个（最可靠：直接看结果）
 *   3. `homedir()`（ZCode 的默认数据根，其下有 `.zcode`）
 *
 * 注意：这里返回的是**数据根**（其下有 `.zcode` 子目录），不是 `.zcode` 本身。
 */
export declare function resolveDataBaseDir(): string;
/**
 * 发现文件的绝对路径。
 *
 * 取**第一个真的存在发现文件**的候选目录；都不存在时退回首选目录的路径
 * （语义上表示"桥没有把文件写在那里"）。
 *
 * 这里不能简单地用 `resolveDataBaseDir()` —— 那个函数只做环境变量与候选
 * 推断，不保证文件真的在。写路径的调用方（保活）需要知道**实际的文件位置**。
 */
export declare function resolveBridgePortFilePath(): string;
/**
 * 读发现文件。
 *
 * 任何异常（不存在、JSON 坏、schema 版本不符、字段缺失）一律返回 undefined ——
 * 调用方据此报"桥未运行"，**不要**让它把异常抛到请求路径上（那会变成
 * 难以理解的 provider 报错）。
 */
export declare function readBridgePortFile(filePath?: string): ZCodeBridgePortFile | undefined;
/**
 * 解析出可用的桥端点。
 *
 * ## 查找顺序（多候选，不依赖单一环境变量的新鲜度）
 *
 *   1. `ZCODE_BRIDGE_BASE_URL` + `ZCODE_BRIDGE_TOKEN`（显式覆盖，最高优先）
 *   2. `resolveDataBaseDir()` 给出的目录（环境变量 → 有文件的候选 → homedir）
 *   3. 其余候选目录 —— **只要任何一个目录里有发现文件，就用它**
 *
 * 第 3 条是应对「launcher 环境块过期」的兜底：环境变量可能指错地方，
 * 但发现文件是**实际存在的事实**，以它为准。
 *
 * 返回 undefined 表示**桥不可用**（ZCode 实例没在跑，或没开 `ZCODE_BRIDGE=1`）。
 * 调用方必须区分"桥不可用"（隐藏 provider）与"请求失败"（报错）。
 */
export declare function resolveBridgeEndpoint(): ZCodeBridgeEndpoint | undefined;
/**
 * 解析出**确实活着**的桥端点 —— 候选目录逐个 `/health` 探活，择优返回。
 *
 * ## 为什么必须有这个函数（2026-09-27 实测踩过，这是"壳反复消失"的真根因）
 *
 * 机器上可能同时存在**多份**发现文件：环境变量指向的目录里躺着**上一个
 * 已死实例**写下的文件，而**当前活着的实例**把文件写在了别处
 * （实测：`D:\...\_oss_data` 里是死端口 57653，`C:\Users\Administrator\.zcode`
 * 里是活端口 56483）。
 *
 * `resolveBridgeEndpoint()` 会返回**排在最前**的那个，不管它死没死。
 * 一旦它返回死端口：
 *
 *   `probeBridge()` false → 保活判「壳死了」
 *     → `killResidualInstances()` 杀掉**正在正常服务**的那个实例
 *     → spawn 新实例 → 新实例又把文件写到别处 → 再判死 → 死循环
 *
 * 观测现象：进程树每 10-30 秒整体消失一次，桥却从来没坏过。
 *
 * ⇒ **候选之间用探活来裁定，不用"谁是第一个"来裁定。**
 *   先试首选候选（省一次 HTTP），失败再并发探其余候选。
 */
export declare function resolveLiveBridgeEndpoint(timeoutMs?: number): Promise<ZCodeBridgeEndpoint | undefined>;
/**
 * 探测桥是否真的活着（HTTP `/health`，**不需要 token**）。
 *
 * 光有发现文件不够 —— 实例可能已经崩了但文件还在。这个探测很轻
 * （本地 loopback，毫秒级），用于 `listModels` 的门控：桥不在就让
 * provider 整个隐藏，而不是给用户一个点不动的分组。
 */
export declare function probeBridge(endpoint: ZCodeBridgeEndpoint, timeoutMs?: number): Promise<boolean>;
//# sourceMappingURL=bridge-endpoint.d.ts.map