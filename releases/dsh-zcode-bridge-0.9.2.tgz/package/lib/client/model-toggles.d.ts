/**
 * ZCode 桥 —— 客户端 UI（模型设置页的 provider 卡片扩展区）。
 *
 * ## 用户要求（逐条对应本文件的结构）
 *
 * > 「模型右侧的按钮改成【编辑】点编辑后展开，展开后原本输入 apikey 的地方
 * >   改成咱们的【添加账号】【签到】【持续领取】，下面就是咱们的 tab，
 * >   模型|账号管理」
 *
 * 对应实现：
 *   - **tab 分栏**：「模型」与「账号管理」两个 tab，见 `buildTabs()`
 *   - **模型 tab**：模型开关行（已有逻辑，`renderModelToggles` 复用）
 *   - **账号管理 tab**：添加账号 / 签到 / 持续领取三个操作，
 *     见 `renderAccountPanel()` 与 `deps.accounts.*`
 *
 * ## 挂载点与「编辑」的关系（实测契约）
 *
 * `settings.models.provider-card` 是 DSH 官方模型设置页的扩展槽。
 * 官方 `dsh-client-ui-settings-models/lib/client.js` 的渲染顺序是：
 *
 * ```js
 * renderSlot("settings.models.provider-card", { provider, configured, keyConfigured }),
 * open ? renderProviderEditor({ ... }) : ...
 * ```
 *
 * ⇒ **本组件渲染在官方编辑器「之前」**，即用户点「编辑」展开后，
 *   我们的内容出现在官方凭据编辑器**上方**。
 *
 * ⚠ 官方那个 api-key 输入框由官方渲染，插件**无法替换它**（槽只提供追加，
 *   不提供替换）。所以「原本输入 apikey 的地方改成我们的按钮」在契约层面
 *   做不到 —— 折中做法是**把我们的按钮放在它上面**，视觉上先出现，
 *   并在空状态提示里说明「ZCode 不需要填 api-key」。
 *
 * ## 为什么不用 React
 *
 * 宿主页面是 React，但这个扩展槽只要求「一个渲染函数」。用原生 DOM
 * 可以完全避开对 React 版本/JSX 构建的耦合 —— 插件的 `lib/` 是纯 tsc
 * 产物，没有 JSX 编译步骤。
 *
 * ## 「实时生效」的实现
 *
 * 开关写入 → 宿主 `settings` 落盘 + 适配器进程内副本更新。
 * 模型选择器下次打开时调 `listModels()`，读到的是**过滤后的新目录**。
 * 不需要任何事件广播 —— 见 `adapter.ts` 的 `listModels()`。
 *
 * 本组件只负责把「全量目录 + 开关状态」渲染出来。全量目录必须走
 * `listAllModels()`（不过滤），否则被关闭的模型会连开关一起消失，
 * 用户再也无法重新打开。
 */
/** 组件收到的 owner props（由宿主 dispatch 注入）。 */
export interface ProviderCardOwnerProps {
    /** 该卡片的目录行。 */
    readonly provider: {
        readonly provider: string;
        readonly displayName: string;
        readonly settingsNs: string;
        readonly settingsPath: readonly string[];
        readonly active: boolean;
        readonly declared?: boolean;
        readonly error?: string;
    };
    /** 是否有任一配置层配置了该 provider。 */
    readonly configured: boolean;
    /** 引用的 api-key 凭据是否已配置。 */
    readonly keyConfigured: boolean;
}
/** 客户端上下文里我们用到的最小面。 */
export interface ClientCtx {
    readonly logger?: {
        info?: (m: unknown) => void;
        warn?: (m: unknown) => void;
    };
    readonly get?: (name: string) => unknown;
}
/** 账号状态（由 Host 侧桥查询后返回）。 */
export interface AccountStatus {
    /** 账号标识（脱敏后的展示名）。 */
    readonly label: string;
    /** 是否已登录。 */
    readonly signedIn: boolean;
    /** 额度描述（如「3,000,000 / 3,000,000」）。 */
    readonly quota?: string;
    /** 权益到期描述。 */
    readonly expiresAt?: string;
    /** 当前生效的 provider（如 account:bigmodel-start-plan）。 */
    readonly providerId?: string;
    /** 权益覆盖的模型 id 列表 —— UI 据此标注哪些模型可用。 */
    readonly entitledModels?: readonly string[];
}
/** 签到/领取的操作结果。 */
export interface ClaimResult {
    readonly ok: boolean;
    /** 面向用户的一句话结果说明。 */
    readonly message: string;
}
/** 宿主注入的依赖（由 apply 时的闭包提供）。 */
export interface ModelToggleDeps {
    /** 本 provider 的路由名。 */
    readonly providerId: string;
    /** 本插件的 settings namespace（用于判断是否该渲染）。 */
    readonly settingsNs: string;
    /** 全量模型目录（不过滤）。 */
    listAllModels: () => readonly {
        id: string;
        name: string;
    }[];
    /** 某 model 当前是否被关闭。 */
    isDisabled: (modelId: string) => boolean;
    /** 打开/关闭某 model。 */
    setDisabled: (modelId: string, disabled: boolean) => Promise<void>;
    /**
     * 账号相关操作。**全部可选** —— Host 侧桥未提供时，账号管理 tab
     * 显示"不可用"而不是抛错（与适配器「桥不在就隐藏分组」同思路）。
     */
    accounts?: {
        /** 查询当前账号状态。 */
        status?: () => Promise<AccountStatus | undefined>;
        /** 添加账号（触发实例的 OAuth 登录）。 */
        addAccount?: () => Promise<ClaimResult>;
        /** 每日签到。 */
        checkin?: () => Promise<ClaimResult>;
        /** 持续领取（定时自动领取开关）。 */
        startAutoClaim?: () => Promise<ClaimResult>;
        /** 查询持续领取是否运行中。 */
        autoClaimRunning?: () => boolean;
    };
}
/**
 * 渲染 provider 卡片里的模型开关区。
 *
 * 返回一个 DOM 元素；宿主把它插进卡片。
 */
export declare function renderModelToggles(props: ProviderCardOwnerProps, deps: ModelToggleDeps, ctx: ClientCtx): HTMLElement | null;
//# sourceMappingURL=model-toggles.d.ts.map