/**
 * DSH 插件：ZCode 桥 provider。
 *
 * 把 ZCode 开源版实例内部的**免费额度通道**（`account:bigmodel-start-plan`
 * + 阿里云 captcha）接进 DSH，作为一个普通模型 provider 使用。
 *
 * ## 架构
 *
 *   DSH ──▶ 本插件 ──▶ 本机 HTTP 桥 ──▶ ZCode 实例的 session 链路 ──▶ zcode.z.ai
 *          (provider)      (loopback)        (createTask/sendPrompt)     (免费额度)
 *
 * ## 为什么必须经过 ZCode 实例（妥协条件）
 *
 * 免费额度通道强制要求阿里云 captcha，而 captcha 只能在真实 Electron
 * renderer 里运行（需要 DOM + CDN 脚本）。且 3012 风控的判据是**调用路径** ——
 * 只有实例内部的 session 链路（`createTask` + `sendPrompt`）能通过，
 * 裸 HTTP 调用一律 405/3012。
 *
 * **⇒ 使用本插件的前提：本机已安装并运行 ZCode 开源版实例（`ZCODE_BRIDGE=1`）。**
 * 用 `D:\zcode-glm5.3f\scripts\start-headless.ps1` 可无头静默启动。
 *
 * ## 独立运行
 *
 * 本插件不依赖 Jet Hub。桥不可用（ZCode 没跑）时，`listModels()` 返回 `[]`，
 * DSH 会把整个 provider 分组隐藏 —— 不会留下一个点不动的条目。
 */
import type { Context } from "@deepseek-ai/cordis";
import z from "@deepseek-ai/schemastery";
import { ZCodeBridgeAdapter } from "./adapter.js";
export declare const Config: z<{
    disabledModels: Record<string, Record<string, boolean>>;
    quotaCheckIntervalMinutes: number;
    quotaFailureCooldownMinutes: number;
    quotaGuardDisabled: boolean;
    captchaPoolEnabled: boolean;
    injectedJwt: string;
}>;
/** 插件名（与 package.json 的 `name` 保持一致）。 */
export declare const name = "zcode-bridge";
/**
 * 静态注入的服务。
 *
 * ⚠ **不含 `credentials`** —— 本 provider 不要用户配置任何凭据
 * （端口与 token 都从桥的发现文件自动读取）。把 `credentials` 列进来
 * 会让插件在 headless/CLI profile 里永久 pending，进而整个 profile 以
 * `plugin tree failed to load` 启动失败。
 *
 * ⚠ **不含 `settings`** —— 该服务通过 `ctx.get('settings')` 可选取用，
 * 静态注入同样会在没有它的 profile 里卡住。
 */
export declare const inject: string[];
/** 取回已注册的适配器实例（未注册时 undefined）。 */
export declare function getRegisteredZCodeBridgeAdapter(): ZCodeBridgeAdapter | undefined;
/**
 *
 * 注册顺序：先探 settings（诊断用），再 provider 声明 + 适配器 + 保活。
 */
export declare function apply(ctx: Context): Promise<void>;
export declare namespace apply {
    var Config: z<{
        disabledModels: Record<string, Record<string, boolean>>;
        quotaCheckIntervalMinutes: number;
        quotaFailureCooldownMinutes: number;
        quotaGuardDisabled: boolean;
        captchaPoolEnabled: boolean;
        injectedJwt: string;
    }>;
}
//# sourceMappingURL=index.d.ts.map