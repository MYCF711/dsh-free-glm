/**
 * ZCode 实例的生命周期绑定。
 *
 * ## 解决的问题
 *
 * 桥跑在 ZCode 实例（electron）里。`start-headless.ps1` 用 `Start-Process`
 * 启动它，父进程（pwsh）随即退出 —— **实例变成孤儿进程，永远活着**。
 *
 * 后果：DSH 关了，实例还在，白占 ~400 MB 内存，而且没有托盘图标可以关它
 * （`ZCODE_HEADLESS=1` 把托盘也禁了）。用户只能开任务管理器。
 *
 * ## 做法
 *
 * 插件在 DSH 进程里挂 `process.on("exit" / SIGINT / SIGTERM)`，退出时
 * 把实例一起带走。
 *
 * ### 为什么必须钩 `process`，不能只靠 `ctx.effect()`
 *
 * `ctx.effect()` 的清理只在**插件被热卸载**时跑，进程被 kill 时不会。
 * 而我们要覆盖的恰恰是后者。cordis 也没有进程级退出事件
 * （`Events` 接口里只有 `internal/*`）。
 *
 * ### 为什么钩 `exit` 而不是 `beforeExit`
 *
 * `beforeExit` 在事件循环空转时触发，**可以被后续任务撤销** —— 不适合做
 * 收尾。`exit` 是最后时机，只允许同步操作，所以这里用 `taskkill` 的
 * 同步形式（`execFileSync`）。
 *
 * ### 只杀自己启动的实例
 *
 * 如果用户是**手动**用 `start-headless.ps1` 起的（或本来就开着官方 ZCode），
 * 我们不能替他决定关掉。判据见 {@link shouldOwnInstance}：
 * 只有当实例是**本插件启动的**（记了 pid）才会被带走。
 */
/** 启动 ZCode 实例所需的配置。 */
export interface ZCodeInstanceSpawnConfig {
    /** electron 可执行文件。 */
    readonly electronPath: string;
    /** app 目录（含 package.json，其 main 指向入口）。 */
    readonly appDir: string;
    /** 数据根目录。 */
    readonly dataBaseDir: string;
    /** 就绪等待上限（毫秒）。 */
    readonly readyTimeoutMs?: number;
}
/**
 * 判断是否应该由本插件接管实例的生命周期。
 *
 * 只有在**两端都满足**时才接管：
 *   1. 桥不是由环境变量显式指定的（`ZCODE_BRIDGE_BASE_URL` 为空）——
 *      显式指定说明用户自带实例，我们不该杀它；
 *   2. 实例是**本插件启动的**（`owned` 有记录）。
 *
 * 手动运行 `start-headless.ps1` 起的实例不会被这里碰到 —— 用户明确
 * 用了那个脚本，说明他要自己管。
 */
export declare function shouldOwnInstance(): boolean;
/** 记录本插件启动的实例 pid。 */
export declare function rememberOwnedInstance(pid: number): void;
/**
 * 杀掉本插件启动的实例。
 *
 * 用 `taskkill /T /F` —— `/T` 连带子进程（electron 有 8-10 个子进程，
 * 只杀主进程会留下一堆渲染进程孤儿），`/F` 强制（窗口已隐藏，
 * 没法走正常关闭流程）。
 *
 * 任何异常都吞掉：这是退出路径，不能因为清理失败而让 DSH 挂住。
 */
export declare function killOwnedInstance(): void;
/**
 * 安装进程退出钩子。
 *
 * 幂等：重复调用只有第一次生效。
 *
 * `exit` 里只做同步 kill；`SIGINT` / `SIGTERM` 里先 kill 再以标准
 * 退出码退出（否则 Ctrl+C 会变成"没反应"）。
 */
export declare function installInstanceLifecycleHooks(logger: {
    info: (...args: unknown[]) => void;
    warn: (...args: unknown[]) => void;
}): void;
/**
 * 读发现文件里的实例 id。
 *
 * 用于判断"已经在跑的那个"是不是我们之前启动的 —— 重启 DSH 后
 * `owned` 是空的，但实例可能还在跑（上一次没清干净）。
 */
export declare function readExistingInstanceId(): string | undefined;
/** 读发现文件里的 pid（桥写进去的，用于保活判定）。 */
export declare function readExistingInstancePid(): number | undefined;
/**
 * 读发现文件里的端口。
 *
 * 用于「新实例是否已经接管」的判定：新实例的桥会绑一个新端口，
 * 端口值变了就说明换了实例 —— 这个判据不依赖删文件。
 */
export declare function readExistingPort(): number | undefined;
/** 进程是否还活着（Windows 用 tasklist，POSIX 用 signal 0）。 */
export declare function isProcessAlive(pid: number): boolean;
/**
 * 保活状态机。
 *
 * ## 语义（双向绑定）
 *
 *   DSH 活 → 壳必须活：探活失败就重启
 *   DSH 死 → 壳跟着死：`process.on('exit'/'SIGINT'/'SIGTERM')` 里 kill
 *
 * ## 为什么需要保活
 *
 * 壳可能因为各种原因挂掉（OOM、崩溃、被误杀），而 DSH 侧的插件是无感的
 * —— `listModels()` 会返回 `[]`，用户看到 provider 分组凭空消失，
 * 下一次请求报 `MISSING_CREDENTIAL`。保活把它变成一个可自愈的状态。
 *
 * ## 为什么不用 `ctx.effect` 做清理
 *
 * 那只覆盖插件热卸载；进程被 kill 时不跑。收尾必须挂在 `process` 上。
 */
export interface KeepAliveHandle {
    stop(): void;
}
/** 保活配置。 */
export interface KeepAliveConfig {
    /** 检查间隔（毫秒）。 */
    readonly intervalMs: number;
    /** 连续失败多少次后尝试重启。 */
    readonly failuresBeforeRestart: number;
    /** 重启时的实例配置；省略则只报日志不重启。 */
    readonly spawn?: ZCodeInstanceSpawnConfig;
}
/**
 * 启动保活循环。
 *
 * 同时装上进程退出钩子（DSH 死 → 壳死）。
 */
export declare function startKeepAlive(config: KeepAliveConfig, logger: {
    info: (...args: unknown[]) => void;
    warn: (...args: unknown[]) => void;
}): KeepAliveHandle;
/**
 * 启动一个新的 ZCode 实例并等它就绪。
 *
 * 只在 `ZCODE_BRIDGE_AUTOSTART=1` 时被调用 —— 默认不自启，因为
 * 实例启动要 ~30 秒、占 ~400 MB，用户可能更愿意自己控制。
 */
export declare function spawnZCodeInstance(config: ZCodeInstanceSpawnConfig, logger: {
    info: (...args: unknown[]) => void;
    warn: (...args: unknown[]) => void;
}): Promise<number | undefined>;
//# sourceMappingURL=instance-lifecycle.d.ts.map